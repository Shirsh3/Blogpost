package com.example.demo;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@SpringBootApplication

public class Lab3ClientApplication  extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(Lab3ClientApplication.class, args);
	}
	

	  
	  @Override
		protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
			
			return builder.sources(Lab3ClientApplication.class);
		}
}
