package com.example.demo;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class SentenceController {

	
	NounClient nounClient;
	AdjectiveClient adjClient;
	VerbClient verbClient;
	SubjectClient subjClient;
	ArticleClient artClient;
	
	@Autowired
	public void setNounClient(NounClient nounClient) {
		this.nounClient = nounClient;
	}

	@Autowired
	public void setAdjClient(AdjectiveClient adjClient) {
		this.adjClient = adjClient;
	}

	@Autowired
	public void setVerbClient(VerbClient verbClient) {
		this.verbClient = verbClient;
	}

	@Autowired
	public void setSubjClient(SubjectClient subjClient) {
		this.subjClient = subjClient;
	}

	@Autowired
	public void setArtClient(ArticleClient artClient) {
		this.artClient = artClient;
	}


	@RequestMapping("/sentence")
	public String buildSentence() {
		StringBuffer sentence = new StringBuffer(subjClient.getWord() + "\t");
		StringBuffer verbWord = sentence.append(verbClient.getWord() + "\t" );
		String articleWord = artClient.getWord() +"\t";
		String adjectiveWord = adjClient.getWord()+"\t";
		String nounWord = nounClient.getWord();
		return (verbWord.append(articleWord).append(adjectiveWord).append(nounWord)).toString();
	}
	
	

}
