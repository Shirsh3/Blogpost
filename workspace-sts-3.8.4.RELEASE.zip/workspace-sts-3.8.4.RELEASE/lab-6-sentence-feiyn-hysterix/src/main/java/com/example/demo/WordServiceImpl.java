package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class WordServiceImpl implements WordService {

	@Autowired NounClient nounClient;
	@Autowired AdjectiveClient adjClient;
	@Autowired VerbClient verbClient;
	@Autowired SubjectClient subjClient;
	@Autowired ArticleClient artClient;


	@Override
	public String getWord() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	@HystrixCommand(fallbackMethod="getFallbackSubject")
	public String getSubject() {

		return subjClient.getWord();
	}


	@Override
	@HystrixCommand(fallbackMethod="getFallbackVerb")
	public String getVerb() {

		return verbClient.getWord(); 
	}


	@Override
	@HystrixCommand(fallbackMethod="getFallbackArticle")
	public String getArticle() {
		// TODO Auto-generated method stub
		return artClient.getWord();
	}


	@Override
	@HystrixCommand(fallbackMethod="getFallbackAdjective")
	public String getAdjective() {
		// TODO Auto-generated method stub
		return adjClient.getWord();
	}


	@Override
	@HystrixCommand(fallbackMethod="getFallbackNoun")
	public String getNoun() {
		// TODO Auto-generated method stub
		return nounClient.getWord();
	}

	public String getFallbackNoun(){

		return "Fallback Noun";
	}

	public String getFallbackSubject(){

		return "Fallback Subject";
	}
	
	public String getFallbackArticle(){

		return "Fallback Article";
	}

	public String getFallbackAdjective(){

		return "Fallback Adjective";
	}
	
	public String getFallbackVerb(){

		return "Fallback Verb";
	}
	
	
}
