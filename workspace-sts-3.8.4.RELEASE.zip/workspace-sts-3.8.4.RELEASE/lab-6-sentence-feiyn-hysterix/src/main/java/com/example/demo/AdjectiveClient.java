package com.example.demo;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@FeignClient("LAB-4-ADJECTIVE")
public interface AdjectiveClient {

	@RequestMapping(value="/",method=RequestMethod.GET)
	String getWord();
	
	
}
