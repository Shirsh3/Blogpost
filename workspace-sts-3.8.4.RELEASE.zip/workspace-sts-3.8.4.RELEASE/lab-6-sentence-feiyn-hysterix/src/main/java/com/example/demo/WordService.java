package com.example.demo;

public interface WordService {
	
	String getWord();

	String getSubject();

	String getVerb();

	String getArticle();

	String getAdjective();

	String getNoun();
}
