package com.example.demo;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class SentenceController {

	
	@Autowired
	WordService service;


	@RequestMapping("/sentence")
	public String buildSentence() {
		StringBuffer sentence = new StringBuffer(service.getSubject() + "\t");
		StringBuffer verbWord = sentence.append(service.getVerb() + "\t" );
		String articleWord = service.getArticle() +"\t";
		String adjectiveWord = service.getAdjective()+"\t";
		String nounWord = service.getNoun();
		return (verbWord.append(articleWord).append(adjectiveWord).append(nounWord)).toString();
	}
	
	

}
