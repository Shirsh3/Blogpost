package one97.sbiPortal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

@SpringBootApplication(scanBasePackages={"one97.sbiPortal"})
@EntityScan("one97.sbiPortal.model")
public class SbiPortalApplication extends SpringBootServletInitializer{

	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(SbiPortalApplication.class);
    }
	
	public static void main(String[] args) {
		SpringApplication.run(SbiPortalApplication.class, args);
	}
}

