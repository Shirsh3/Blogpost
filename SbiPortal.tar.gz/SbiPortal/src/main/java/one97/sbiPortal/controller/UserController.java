package one97.sbiPortal.controller;

import static one97.sbiPortal.utils.ConstantVariables.SUBMIT;
import static one97.sbiPortal.utils.ConstantVariables.TEST;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.util.LinkedHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import one97.sbiPortal.dto.UserDTO;
import one97.sbiPortal.service.CommonService;
import one97.sbiPortal.service.UserService;
import one97.sbiPortal.service.impl.CommonResponseEntity;
import one97.sbiPortal.utils.ConstantVariables;
import one97.sbiPortal.utils.ResponseCode;

@Controller
@RequestMapping(value = ConstantVariables.BASE_URI)
public class UserController {
	
	@Autowired
	private CommonResponseEntity commonResponseEntity;

	@Autowired
	private CommonService commonService;

	@Autowired
	private UserService userService;
	
	private static Logger logger = Logger.getLogger(UserController.class.getName());
	

	@RequestMapping(value="/",method = RequestMethod.GET)
    public String homepage(HttpServletRequest request,Model model){
		
		model.addAttribute("userform", new UserDTO());
        return "index";
    }
	
	@RequestMapping(value = TEST, method = RequestMethod.GET)
	public LinkedHashMap<String, Object> test(){
		
		LinkedHashMap<String, Object> resultMap=new LinkedHashMap<>();
		resultMap.put("test", "running fine");
		
		return resultMap;
	}
	
	@RequestMapping(value ="/submitInfo", method = RequestMethod.POST)
	public LinkedHashMap<String, Object> test1(){
		
		LinkedHashMap<String, Object> resultMap=new LinkedHashMap<>();
		resultMap.put("test", "running fine");
		
		return resultMap;
	}
	
	@RequestMapping(value = SUBMIT, method = POST)
	public String uploadUserData(@Valid @ModelAttribute("userform") UserDTO dto, BindingResult result,
			HttpServletRequest request,Model model) {

		model.addAttribute("userform", new UserDTO());
		LinkedHashMap<String, Object> resultMap = new LinkedHashMap<>();
		if (result.hasErrors()) {

			return ConstantVariables.INDEX;
		}


		logger.info( "User info" + dto);
		
		userService.uploadData(dto);
		
		return ConstantVariables.INDEX;
	}


}
