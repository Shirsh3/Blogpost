package one97.sbiPortal.dto;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotNull;

public class UserDTO {

	@NotNull(message = "First name can not be null")
	private String firstName;
	
	private String middleName;
	
	private String lastName;
	
	@NotNull(message = "Mobile number can not be null")
	private Long mobileNo;
	
	private String address;
	
	private String pinCode;
	
	private String city;
	
	private Integer age;
	
	private String pan;
	
	private String profession;
	
	private String gender;
	
	@AssertTrue(message = "First name cant be blank")
	private boolean isBlank() {
		return !this.getFirstName().isEmpty();
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getProfession() {
		return profession;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	
	

}
