package one97.sbiPortal.repo;

import one97.sbiPortal.dto.UserDTO;

public interface UserRepository {

	public void save(UserDTO dto);
}
