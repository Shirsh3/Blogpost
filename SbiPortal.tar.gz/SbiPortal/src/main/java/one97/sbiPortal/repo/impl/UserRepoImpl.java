package one97.sbiPortal.repo.impl;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.transaction.Transactional;

import  org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.databind.ObjectMapper;

import one97.sbiPortal.dto.UserDTO;
import one97.sbiPortal.model.User;
import one97.sbiPortal.repo.UserRepository;


@Repository
@Transactional
public class UserRepoImpl implements UserRepository {

	private static Logger logger = Logger.getLogger(UserRepoImpl.class.getName());

	@PersistenceContext
	EntityManager em;

	@Autowired
	ObjectMapper mapper;
	@Override
	public void save(UserDTO dto) {

		logger.info( "In UserDaoImpl, saving user persisting in database");
		try {
			
			User user = mapper.convertValue(dto, User.class);
			user.setCreatedDate(new Date());
   			em.persist(user);
		} catch (PersistenceException e) {
			logger.error( "In UserDaoImpl, exception exists while persisting User data");
			e.printStackTrace();
		}
	}

}
