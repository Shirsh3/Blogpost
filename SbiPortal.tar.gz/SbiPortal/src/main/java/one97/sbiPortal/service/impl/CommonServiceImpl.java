package one97.sbiPortal.service.impl;



import java.util.LinkedHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import one97.sbiPortal.model.ThirdPartyUrl;
import one97.sbiPortal.service.CommonService;
import one97.sbiPortal.service.UserService;




@Service("commonService")
public class CommonServiceImpl implements CommonService {

	
	@Autowired
	private UserService userService;

	@Override
	public LinkedHashMap<String, Object> ExceptionMap(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public LinkedHashMap<String, Object> hitGetThirdParyUrl(ThirdPartyUrl thirdPartyUrl, String parameter) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String createGetUrl(ThirdPartyUrl thirdPartyUrl, String parameter) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String createUrl(ThirdPartyUrl thirdPartyUrl, String parameter) {
		// TODO Auto-generated method stub
		return null;
	}
	
/*	@Override
	public LinkedHashMap<String, Object> ExceptionMap(String msg) {
		LinkedHashMap<String, Object> resultMap = new LinkedHashMap<String, Object>();

		if(msg.equals(ConstantVariables.NFE) || msg.equals(ConstantVariables.CHECK_LENGTH)) {
			resultMap.put(ConstantVariables.REQUEST_STATUS,org.springframework.http.HttpStatus.UNPROCESSABLE_ENTITY);
			resultMap.put(ConstantVariables.RESPONSE_CODE,ResponseCode.PARAM_MISSING_CODE);
		}
		else if(msg.contains(ConstantVariables.NO_OTP_URL)) {
			resultMap.put(ConstantVariables.REQUEST_STATUS,org.springframework.http.HttpStatus.NOT_FOUND);
			resultMap.put(ConstantVariables.RESPONSE_CODE,ResponseCode.ENTITY_NOT_FOUND);
		}
		else {
			resultMap.put(ConstantVariables.REQUEST_STATUS,org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR);
			resultMap.put(ConstantVariables.RESPONSE_CODE,ResponseCode.EXCEPTION_CODE);
		}
		resultMap.put(ConstantVariables.RESPONSE_MSG,msg);
		
		return resultMap;	
	}
	
	@Override
	public LinkedHashMap<String, Object> hitGetThirdParyUrl(ThirdPartyUrl thirdPartyUrl, String parameter) {
		LinkedHashMap<String, Object> resultMap = new LinkedHashMap<String, Object>();
		OkHttpClient client = new OkHttpClient();
		String result =null;
		String requestUrl = createGetUrl(thirdPartyUrl,parameter);
		Request request = new Request.Builder().url(requestUrl).get().build();
		try {
			Response response = client.newCall(request).execute();
			result =response.body().string();
			resultMap.put(ConstantVariables.REQUEST_STATUS,response.message());
			resultMap.put(ConstantVariables.RESPONSE_MSG,result);
			resultMap.put(ConstantVariables.RESPONSE_CODE,response.code());
			resultMap.put(ConstantVariables.URL, requestUrl);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return resultMap;
	}
	
	
	@Override
	public  String createGetUrl(ThirdPartyUrl thirdPartyUrl, String parameter) {
		String url = thirdPartyUrl.getUrl() + thirdPartyUrl.getQuery();
		if(parameter!=null){
			String params[] =parameter.split(",");
			for (int i = 0; i < params.length; i++) {
				url = url.replace("<param" + (i + 1) + ">", params[i]);			
			}
		}
		
		return url;
	}

	
	@Override
	public  String createUrl(ThirdPartyUrl thirdPartyUrl, String parameter) {
		String url = thirdPartyUrl.getUrl() + thirdPartyUrl.getQuery();
		if(parameter!=null){
			String params[] =parameter.split(",");
			for (int i = 0; i < params.length; i++) {
				url = url.replace("<param" + (i + 1) + ">", params[i]);			
			}
		}
		
		return url;
	}
	
	@Override
	public String generateAccessTokenForChangePassword(UserDTO dto,User user) {
		String randomToken = RandomStringUtils.randomAlphabetic(64);

		dto.setAccessToken(randomToken);
		dto.setTokenValid(true);
		
		if(user!=null)
			dto.setTempFlag(user.isTempFlag());
		dto.setTokenExpiry(UtilFunctions.addDays(new Date(), tokenExpiry));
		userService.save(dto);

		return randomToken;
	}
	
	@Override
	public String generateAccessTokenForForgetPassword(UserDTO dto,User user) {
		String randomToken = RandomStringUtils.randomAlphabetic(64);

		if(user!=null && !user.isTempFlag())
			dto.setAccessToken(randomToken);
		dto.setTokenValid(true);
		
		if(user!=null)
			dto.setTempFlag(user.isTempFlag());
		dto.setTokenExpiry(UtilFunctions.addDays(new Date(), tokenExpiry));
		userService.save(dto);

		return randomToken;
	}
*/

}




