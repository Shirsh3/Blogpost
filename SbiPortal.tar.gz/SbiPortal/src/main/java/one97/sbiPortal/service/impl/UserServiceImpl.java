package one97.sbiPortal.service.impl;

import  org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import one97.sbiPortal.dto.UserDTO;
import one97.sbiPortal.repo.UserRepository;
import one97.sbiPortal.service.UserService;

@Service("userDetailsService")
@Component
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	
	private static Logger logger = Logger.getLogger(UserServiceImpl.class.getName());
	
	
	@Override
	public void uploadData(UserDTO dto) {

		logger.info( "save User ::::: " + dto);
		try {
			userRepository.save(dto);
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}


}