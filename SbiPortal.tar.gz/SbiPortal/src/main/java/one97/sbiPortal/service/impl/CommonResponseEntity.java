package one97.sbiPortal.service.impl;


import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import one97.sbiPortal.utils.ConstantVariables;



@Service("commonResponseEntity")
public class CommonResponseEntity{
	
	public  LinkedHashMap<String,Object> responseEntity(Map<String,Object> result) {
		LinkedHashMap<String, Object> resultMap = null;
		resultMap = new LinkedHashMap<String, Object>();
		resultMap.put(ConstantVariables.REQUEST_STATUS,result.get(ConstantVariables.REQUEST_STATUS));
		resultMap.put(ConstantVariables.RESPONSE_MSG,result.get(ConstantVariables.RESPONSE_MSG));
		resultMap.put(ConstantVariables.RESPONSE_CODE,result.get(ConstantVariables.RESPONSE_CODE));	
		return resultMap;
	}
	
	
	public  LinkedHashMap<String,Object>responseEntityWithMap(Object status,Object msg,Object code) {
		LinkedHashMap<String, Object> resultMap = null;
		resultMap = new LinkedHashMap<String, Object>();
		resultMap.put(ConstantVariables.REQUEST_STATUS,status);
		resultMap.put(ConstantVariables.RESPONSE_MSG,msg);
		resultMap.put(ConstantVariables.RESPONSE_CODE,code);	
		
		return resultMap;
	}


	public LinkedHashMap<String, Object> responseEntityWithMapAndData(Object status, Object msg,Map data,
			Object code) {
		LinkedHashMap<String, Object> resultMap = null;
		
		resultMap = new LinkedHashMap<String, Object>();
		resultMap.put(ConstantVariables.REQUEST_STATUS,status);
		resultMap.put(ConstantVariables.RESPONSE_MSG,msg);
		resultMap.put(ConstantVariables.RESPONSE_CODE,code);	
		resultMap.put(ConstantVariables.RESPONSE_DATA,data);
		return resultMap;
	}



	public LinkedHashMap<String, Object> responseEntityWithStatusAndResponse(Object status, int code) {

		LinkedHashMap<String, Object> resultMap = null;
		resultMap = new LinkedHashMap<String, Object>();
		resultMap.put(ConstantVariables.REQUEST_STATUS,status);
		resultMap.put(ConstantVariables.RESPONSE_CODE,code);	
		return resultMap;
	}

}
