package one97.sbiPortal.service;

import java.util.LinkedHashMap;

import one97.sbiPortal.model.ThirdPartyUrl;

public interface CommonService {

	LinkedHashMap<String, Object> ExceptionMap(String string);

	LinkedHashMap<String, Object> hitGetThirdParyUrl(ThirdPartyUrl thirdPartyUrl, String parameter);

	String createGetUrl(ThirdPartyUrl thirdPartyUrl, String parameter);

	String createUrl(ThirdPartyUrl thirdPartyUrl, String parameter);


}
