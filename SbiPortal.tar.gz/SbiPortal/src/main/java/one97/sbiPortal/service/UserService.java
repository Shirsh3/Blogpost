package one97.sbiPortal.service;

import one97.sbiPortal.dto.UserDTO;

public interface UserService {

	public void uploadData(UserDTO dto);
		

}
