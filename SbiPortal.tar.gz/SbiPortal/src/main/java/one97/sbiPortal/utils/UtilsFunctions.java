package one97.sbiPortal.utils;

public class UtilsFunctions {
	
	public static boolean validatemsisdn(Long msisdn) {
		
		
		if (Math.floor(Math.log10(msisdn) + 1) != 10) {
			return false;
		}
		return true;
	}


}
