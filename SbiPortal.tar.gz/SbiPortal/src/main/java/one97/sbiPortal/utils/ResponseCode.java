package one97.sbiPortal.utils;

public class ResponseCode {

	public static int PARAM_MISSING_CODE = 4000 ; //Bed request / parameter missing
	public static int SUCCESS_CODE = 2000; //Success

}
