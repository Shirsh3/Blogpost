package one97.sbiPortal.utils;

public class ConstantVariables {
	
	public static final String BASE_URI = "v1";
	public static final String APPNAME = "sbi";

	//Response constants
	public static final String RESPONSE_CODE = "code";
	public static final String URL = "url";
	public static final String EMPTY = "";
	public static final String RESPONSE_MSG = "msg";
	public static final String REQUEST_STATUS = "status";
	public static final String REQUEST_FAIL = "FAILURE";
	public static final String RESPONSE_DATA = "data";
	public static final String STATUS_CODE = "statusCode";
	public static final String MSG_INFO = "messageInfos";
	public static final String MSG = "message";
	public static final String UPLOADED_SUCCESSFULLY = " Records uploaded successfully";
	public static final String TEST = "test";
	public static final String SUBMIT = "submit";
	public static final String INDEX = "index";
	


}
