package one97.sbiPortal.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "third_party_url")
public class ThirdPartyUrl {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id", nullable = false, updatable = false)
	private Long id;

	@Column(name = "query", nullable = false)
	private String query;

	@Column(name = "url", nullable = false)
	private String url;

	@Column(name = "name", nullable = false)
	private String name;

	@Column(name = "dblog", nullable = false)
	private int dblog;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDblog() {
		return dblog;
	}

	public void setDblog(int dblog) {
		this.dblog = dblog;
	}

	
}
