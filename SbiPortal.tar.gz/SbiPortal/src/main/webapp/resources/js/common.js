	
function errorMsgTimeout(){
	setTimeout(function(){ document.getElementById("errorDiv").innerHTML=""; }, 3000);
}

	function validate(){
	var div = document.getElementById("errorDiv");
       if ($('#firstName').val() == '') {
			
    	   div.innerHTML = "First Name cannot be left blank.";
			errorMsgTimeout();			
			return false;
		}
       
       if ($('#lastName').val() == '') {
			
			div.innerHTML = "Last Name cannot be left blank.";
			errorMsgTimeout();			
			return false;
		}
		if ($('#mobileNo').val() == '') {
			div.innerHTML = "Mobile No cannot be left blank.";
			errorMsgTimeout();
			return false;
		}if ($('#mobileNo').val().length < 10) {
			div.innerHTML = "Please enter the valid 10 digit mobile no.";
			errorMsgTimeout();
			return false;
		}
		if ($('#city').val() == '') {

			div.innerHTML = "City cannot be left blank.";
			errorMsgTimeout();
			return false;
		}
		if ($('#pincode').val() == '') {

			div.innerHTML = "Pincode cannot be left blank.";
			errorMsgTimeout();
			return false;
		}
		if ($('#age').val() == '') {

			div.innerHTML = "Age cannot be left blank.";
			errorMsgTimeout();
			return false;
		}
		if(document.getElementById("age")<10)
			{

			div.innerHTML = "Sorry, you are not eligible for this";
			errorMsgTimeout();
			return false;
			}
		
	
	}		
		

/*function checkName(){
	console.log("checkName");
	var div = document.getElementById("errorDiv");
	var name=document.getElementById("username").value;
	console.log(name);
	if(name!=''&& name.trim() != "")
	{
	 var arr= name.split(' ');
	if(arr[0]==arr[1])
		{
		console.log(arr);
		div.innerHTML = "First and second name cannot be same.";
		errorMsgTimeout();
		return false;
		}
    }else{
 		div.innerHTML = "Name cannot be left blank.";
 		errorMsgTimeout();
 		return false;   	
    }
}*/

function isNumber(evt) {

evt = (evt) ? evt : window.event;
var charCode = (evt.which) ? evt.which : evt.keyCode;
var whichCode = evt.which;
if ((charCode >= 48 && charCode <= 57) || (charCode == 8) || (charCode == 9)
		|| (charCode == 37 && whichCode == 0)
		|| (charCode == 39 && whichCode == 0)
		|| (charCode == 46 && whichCode == 0)) {
	return true;
}
return false;
}

/*function otherCities()
{
	if ($('#city').val() =="others")
	{
	console.log("hi others");
	// $('.pageForm').append('<div class="has-float-label"><form:input id="city" path="city" placeholder="City.." type="text" /></div>');
	$("#dynamicCity").css("display","block");
	return false;
	}	
}*/
/*function professionFun(pro){
	document.getElementById("profession-selected").value = pro;
}*/
